
#---------------Program2-template--------------------

class environment:
    loc_x
    loc_y
    
    """Class to define the shore."""
    def percept():
        
class agent:
    """Class that defines agent"""
        
    def move_left(self):
            """Perform action moves left"""
            
                          
    def move_right(self):
            """Perform action moves right"""
        
    def move_up(self):
            """Perform action moves up"""
            
                          
    def move_down(self):
            """Perform action moves down"""
        
       
        
        

        
        

